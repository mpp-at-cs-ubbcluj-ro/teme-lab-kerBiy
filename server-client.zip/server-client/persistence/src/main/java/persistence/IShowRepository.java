package persistence;

import models.Show;

public interface IShowRepository extends ICrudRepository<Long, Show> {
}
