package network.protocol;

public enum RequestType {
    LOGIN,
    LOGOUT,
    GET_ALL_SHOWS,
    SELL_TICKET,
    GET_TICKETS_FOR_SHOW
}