package network.protocol;

public enum ResponseType {
    OK,
    ERROR,
    LOGIN_SUCCESS,
    SHOWS_LIST,
    TICKETS_LIST,
    SHOW_UPDATED
}